#include<stdio.h>
#include<stdlib.h>
#include<math.h>

/* This program is prepared by Syed Asad Jamil. Reg no. SP22-BSE-123. Section: B on 27/03/2022
(This Program find that numbers which is even and also divisible by three). */

int main()
{
    int n0, n1, n2 ,n3, n4, n5, n6, n7, n8, n9;
    {
        printf("Enter Numbers : ");
        scanf("%d%d%d%d%d%d%d%d%d%d",&n0, &n1, &n2, &n3, &n4, &n5, &n6, &n7, &n8, &n9);
    }
    if(n0%2==0 && n0%3==0)
    {
        printf("\n%d is Even number and divisible by three!!!\n",n0);
    }
    if(n1%2==0 && n1%3==0)
    {
        printf("%d is Even number and divisible by three!!!\n",n1);
    }
    if(n2%2==0 && n2%3==0)
    {
        printf("%d is Even number and divisible by three!!!\n",n2);
    }
    if(n3%2==0 && n3%3==0)
    {
        printf("%d is Even number and divisible by three!!!\n",n3);
    }
    if(n4%2==0 && n4%3==0)
    {
        printf("%d is Even number and divisible by three!!!\n",n4);
    }
    if(n5%2==0 && n5%3==0)
    {
        printf("%d is Even number and divisible by three!!!\n",n5);
    }
    if(n6%2==0 && n6%3==0)
    {
        printf("%d is Even number and divisible by three!!!\n",n6);
    }
    if(n7%2==0 && n7%3==0)
    {
        printf("%d is Even number and divisible by three!!!\n",n7);
    }
    if(n8%2==0 && n8%3==0)
    {
        printf("%d is Even number and divisible by three!!!\n",n8);
    }
    if(n9%2==0 && n9%3==0)
    {
        printf("%d is Even number and divisible by three!!!\n",n9);
    }

return 0;
}
